package com.example.lab1.model;

public class RaceConfig {
    private String tortuga;
    private int apuesta;
    private String tipoPista;

    public String getTortuga() { return tortuga; }
    public void setTortuga(String tortuga) { this.tortuga = tortuga; }

    public int getApuesta() { return apuesta; }
    public void setApuesta(int apuesta) { this.apuesta = apuesta; }

    public String getTipoPista() { return tipoPista; }
    public void setTipoPista(String tipoPista) { this.tipoPista = tipoPista; }
}

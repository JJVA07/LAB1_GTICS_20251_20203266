package com.example.lab1.model;

import java.util.*;

public class RaceSession {

    public static class Tortuga {
        String nombre;
        int velocidad;
        int resistencia;
        int suerte;
        double rendimiento;

        public Tortuga(String nombre, int velocidad, int resistencia, int suerte) {
            this.nombre = nombre;
            this.velocidad = velocidad;
            this.resistencia = resistencia;
            this.suerte = suerte;
        }

        public void calcularRendimiento() {
            Random random = new Random();
            double valorAleatorio = random.nextDouble();
            rendimiento = (velocidad * 1.5) + (resistencia * 1.2) + (valorAleatorio * suerte);
        }

        public String getNombre() { return nombre; }
        public double getRendimiento() { return rendimiento; }

        public int getVelocidad() { return velocidad; }
        public int getResistencia() { return resistencia; }
        public int getSuerte() { return suerte; }
    }

    private final Map<String, Tortuga> mapaTortugas = new HashMap<>();
    private List<Tortuga> resultados;

    public RaceSession() {
        mapaTortugas.put("Raphael", new Tortuga("Raphael", 3, 4, 5));
        mapaTortugas.put("Leonardo", new Tortuga("Leonardo", 4, 5, 2));
        mapaTortugas.put("Donatello", new Tortuga("Donatello", 2, 5, 3));
        mapaTortugas.put("Michelangelo", new Tortuga("Michelangelo", 5, 2, 4));
    }

    public void simularCarrera() {
        for (Tortuga tortuga : mapaTortugas.values()) {
            tortuga.calcularRendimiento();
        }

        resultados = new ArrayList<>(mapaTortugas.values());
        resultados.sort(Comparator.comparingDouble(Tortuga::getRendimiento).reversed());
    }

    public List<Tortuga> getResultados() {
        return resultados;
    }

    public Collection<Tortuga> getTortugas() {
        return mapaTortugas.values();
    }

    public Tortuga getTortugaPorNombre(String nombre) {
        return mapaTortugas.get(nombre);
    }
}

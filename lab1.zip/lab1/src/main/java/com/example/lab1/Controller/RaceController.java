package com.example.lab1.Controller;

import com.example.lab1.model.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class RaceController {

    private final RaceSession sesionCarrera = new RaceSession();

    @GetMapping("/")
    public String mostrarFormulario(Model modelo) {
        modelo.addAttribute("configuracionCarrera", new RaceConfig());
        modelo.addAttribute("tortugas", sesionCarrera.getTortugas());
        return "config";
    }

    @PostMapping("/iniciar")
    public String procesarCarrera(@ModelAttribute RaceConfig configuracionCarrera, Model modelo) {
        sesionCarrera.simularCarrera();
        var resultados = sesionCarrera.getResultados();

        modelo.addAttribute("resultados", resultados);
        modelo.addAttribute("tortugaSeleccionada", configuracionCarrera.getTortuga());
        modelo.addAttribute("apuesta", configuracionCarrera.getApuesta());

        boolean gano = configuracionCarrera.getTortuga().equals(resultados.get(0).getNombre());
        modelo.addAttribute("gano", gano);
        modelo.addAttribute("premio", gano ? configuracionCarrera.getApuesta() * 2 : 0);

        return "resultado";
    }
}
